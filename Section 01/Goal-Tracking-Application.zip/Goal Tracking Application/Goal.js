class Goal{
    constructor(date, goalText, status){
        this.date = date;
        this.goalText = goalText;
        this.status = status;
    }
}